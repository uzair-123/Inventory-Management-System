<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
  

  

    </li>

      <li>
    <a href="group.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Manage Groups</span>
    </a>
    </li>


  <li>
    <a href="users.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Manage Users</span>
    </a>
    </li>





  <li>
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>Categories</span>
    </a>
  </li>
  <li>


   
 
  

  <li>
    <a  href="product.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Manage Godown Products</span>
    </a>
    </li>


<li>
    <a href="add_product.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Add Godown Products</span>
    </a>
    </li>




  <li>
    <a href="ssales.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Manage Godown Sales</span>
    </a>
    </li>




  <li>
    <a href="add_ssales.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Add Godown Sales</span>
    </a>
    </li>



 <li>
    <a href="pproduct.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Manage Shop Products</span>
    </a>
    </li>






  <li>
    <a href="add_pproduct.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Add Shop Products</span>
    </a>
    </li>






  <li>
    <a href="sales.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Manage Shop Sales</span>
    </a>
    </li>




  <li>
    <a href="add_sale.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Add Shop Sales</span>
    </a>
    </li>

 
  





</ul>
