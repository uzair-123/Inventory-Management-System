

<script type="text/javascript" src= "mousetrap-master/mousetrap.js" ></script>
<script type="text/javascript" src="mousetrap-master/mousetrap.min.js"></script>







<script src="mousetrap-master/mousetrap.min.js"></script>
<script type="text/javascript" src = "jquery-3.2.1.min.js"></script>




<script type="text/javascript">
	
	function search() {
window.location.assign("admin.php")
}

Mousetrap.bind('a',search) 
Mousetrap.bind('s',search)


</script>


