<div class="row">
    <div class="col-md-8">
       <div class="row">
        <!-- CALENDAR-->
        <div class="col-md-12 col-xs-12">    
            <div class="panel panel-primary " data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                        <i class="fa fa-calendar"></i>
                        <?php echo get_phrase('event_schedule');?>
                    </div>
                </div>
                <div class="panel-body" style="padding:0px;">
                    <div class="calendar-env">
                        <div class="calendar-body">
                            <div id="notice_calendar"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-4">
  <div class="row">


<div class="col-md-12">
    <?php


      

  


    $student_id = $this->session->userdata('login_user_id');
    $curMonth = date('m');
    $curYear = date('y');
    $query = $this->db->query(" select due, amount,status,creation_timestamp from invoice where student_id = $student_id and  from_unixtime(creation_timestamp,' %m ') = $curMonth  and  from_unixtime(creation_timestamp,' %y ') = $curYear
      limit 0,1 ");
    if($query->num_rows() > 0) 
    {
    foreach ( $rowVal = $query->result() as $row)
    {   
     $amount= $row->amount;
     $status= $row->status;
     $due= $row->due;
     ?>    
     <div class="tile-stats tile-green">
      <div class="icon"><i class="entypo-user"></i></div>

        <h3>Payment Notification</h3>
        <span style="color:#fff;font-size:14px; text-decoration:underline;" >Date: <?php echo date('M-Y') ?></span>
        <p>Amount : <?php echo $amount; ?></p>
        <p>Due : <?php echo $due; ?></p>
        <p>Status : <?php echo $status; ?></p>
    </div>

    <?php } 
    }
    else {
        ?>

<div class="tile-stats tile-green">
      <div class="icon"><i class="entypo-user"></i></div>

         <h3>Payment Notification</h3>
        <span style="color:#fff;font-size:14px; text-decoration:underline;" >Date: <?php echo date('M-Y') ?></span>
        <p> Invoice has been not generated for this month.</p>
    </div>



   <?php  } ?>


</div>



    <div class="col-md-12">
     <?php
     $current_user = $this->session->userdata('login_type') . '-' . $this->session->userdata('login_user_id');

     $this->db->where('sender', $current_user);
     $this->db->or_where('reciever', $current_user);
     $message_threads = $this->db->get('message_thread')->result_array();
     foreach ($message_threads as $row)
     {


        $unread_message_number = $this->crud_model->count_unread_message_of_thread($row['message_thread_code']);
    ?>       
    <?php if ($unread_message_number ) {
     ?>

       <div class="tile-stats tile-blue">
        <div class="icon"><i class="entypo-mail"></i></div>
        <h3>Message Notification</h3>
        <div class="num" > <?php echo $unread_message_number; ?></div>
        <p>New message</p>

    </div>
    <?php } else {  ?>

         <div class="tile-stats tile-blue">
        <div class="icon"><i class="entypo-mail"></i></div>
        <h3>Message Notification</h3>
        <div class="num"> 0</div>
        <p>New message</p>
    </div>
     <?php } 
    }
  ?>
</div>

</div>
</div>

<div class="col-md-4">
    <div class="row">
        <div class="col-md-12">
            <?php
            $curDate = date('Y-m-d');
            $userId =  $this->session->userdata('login_user_id');
            $student_name= $this->session->userdata('name');
            $query = $this->db->query("Select status from attendance where student_id= $userId and  date = '".$curDate."' ");
            $result=$query->result();
            $status = $result[0]->status;
            if($status==2)
            {
             ?>
             <div class="tile-stats tile-red">
            <h2 style="color: #fff">Attendance Notification</h2>
            <div class="icon"><i class="entypo-users"></i></div>
            <h3>Absent</h3>
            <p>Dear <b style=" font-size: 12px;"><?php echo ucwords($student_name); ?> 
              </b> your attendance has been marked as absent for today. </p>

          </div>


           <?php
       }

       else if($status==1) {  ?>

        <div class="tile-stats tile-red">
            <h2 style="color: #fff">Attendance Notification</h2>
            <div class="icon"><i class="entypo-users"></i></div>
           <h3>Present</h3>
           
           <p>Dear <b style=" font-size: 12px;"><?php echo ucwords($student_name); ?> </b> 
             your attendance has been marked as present for today. </p>

          </div>
       <?php 
   }
   else {
    ?>

     <div class="tile-stats tile-red">
            <h2 style="color: #fff">Attendance Notification</h2>

            <div class="icon"><i class="entypo-users"></i></div>
           <h3>Not Updated</h3>
           <p> Today's attendance has been updated till now.</p>

          </div>

   <?php  }


   ?>

</div>
</div>
</div>




</div> <!-- row div closed -->



<script>
  $(document).ready(function() {

     var calendar = $('#notice_calendar');

     $('#notice_calendar').fullCalendar({
       header: {
          left: 'title',
          right: 'today prev,next'
      },

                    //defaultView: 'basicWeek',
                    
                    editable: false,
                    firstDay: 1,
                    height: 530,
                    droppable: false,
                    
                    events: [
                  <?php 
                  $notices  =   $this->db->get('noticeboard')->result_array();
                  foreach($notices as $row):
                      ?>
                  {
                     title: "<?php echo $row['notice_title'];?>",
                     start: new Date(<?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?>),
                     end:   new Date(<?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?>) 
                 },
                 <?php 
                 endforeach
                 ?>

                 ]
             });
 });
</script>
