<div class="row">
	<div class="col-md-12">
		<div class="panel panel-primary" data-collapsed="0">
        	<div class="panel-heading">
            	<div class="panel-title" >
            		<i class="entypo-plus-circled"></i>
					<?php echo get_phrase('addmission_form');?>
            	</div>
            </div>
			<div class="panel-body">
				
                <?php echo form_open(base_url() . 'index.php?admin/teacher_for_attendance_add/create' , array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => 'multipart/form-data'));?>
	
										
					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('class');?></label>
                        
						<div class="col-sm-5">
				<select name="classDetails" class="form-control" data-validate="required"  data-message-required="<?php echo get_phrase('select a class');?>">
                              <option value=""><?php echo get_phrase('select class');?></option>
                              <?php 
								$classes = $this->db->get('class')->result_array();
								foreach($classes as $row):
									?>
                            	<option value="<?php echo $row['name'].':'.$row['class_id'];?>"><?php echo $row['name'];?></option>                                
								<?php
								endforeach;
							  ?>
                          </select>
						</div> 
					</div>

					<div class="form-group">
						<label for="field-2" class="col-sm-3 control-label"><?php echo get_phrase('teacher');?></label>
		                    <div class="col-sm-5">
		                        <select name="teacherDetails" class="form-control" data-validate="required"  data-message-required="<?php echo get_phrase('select a teacher');?>">
                                <option value="" ><?php echo get_phrase('select teacher');?></option>
								<?php 
                                $teachers=$this->db->get('teacher')->result_array();
                                foreach($teachers as $rowSet)
								{
									?>
		                            <option value="<?php echo $rowSet['name'].':'.$rowSet['teacher_id'];?>"><?php echo $rowSet['name'];?></option>
			                     <?php }
                                 ?>   
			                    </select>
			                </div>
					</div>
					
					
					 <div class="form-group">
						<div class="col-sm-offset-3 col-sm-5">
							<button type="submit" class="btn btn-info"><?php echo get_phrase('Assign');?></button>
						</div>
					</div>
                <?php echo form_close();?>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">

$(document).ready(function() {
    var max_fields      = 17; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment

 $(wrapper).append('<div class="form-inline"><div class="form-group" style="margin-bottom:3px;margin-left:1px;"><input style="margin-right:1px;" placeholder="Enter Relationship" type="text" class="form-control" size="24"  name="label[]"/><input type="text" size="24" placeholder="Enter Name" class="form-control" style="margin-right:1px;"  name="optional[]"/><span style="padding:5px;cursor:pointer;" class="remove_field glyphicon glyphicon-remove" aria-hidden="true"></span> </div> </div>'); //add input box
        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); 
        $(this).parent('div').remove();
         x--;
    })
});

</script>	