<hr />
<div class="row">
	

<form style=" margin-left: 100px;margin-bottom: 100px" action="/action_page.php" method="get">
  <input type="checkbox" name="vehicle" value="Bike"> Student Information<br>
  <input type="checkbox" name="vehicle" value="Car" checked> Teacher Information<br>
   <input type="checkbox" name="vehicle" value="Bike"> Parent Information<br>
  <input type="checkbox" name="vehicle" value="Car" checked> Librarian Information<br>
  <input type="checkbox" name="vehicle" value="Bike"> Class Information<br>
  <input type="checkbox" name="vehicle" value="Car" checked> Subject Information <br>
   <input type="checkbox" name="vehicle" value="Bike"> Accountant Information<br>
  <input type="checkbox" name="vehicle" value="Car" checked> Daily Attendance<br>
    <input type="checkbox" name="vehicle" value="Car" checked> Accounting<br>
   <input type="checkbox" name="vehicle" value="Bike"> Library<br>
  <input type="checkbox" name="vehicle" value="Car" checked> Dormitory<br>
      <input type="checkbox" name="vehicle" value="Car" checked> Notice board<br>
   <input type="checkbox" name="vehicle" value="Bike"> Message<br>
  <input type="checkbox" name="vehicle" value="Car" checked> Settings<br>
    <input type="checkbox" name="vehicle" value="Car" checked> Account<br>
   


  <input style="margin-top: 30px" type="submit" value="Submit">
</form>

	

</div>



    <script>
  $(document).ready(function() {

	  var calendar = $('#notice_calendar');

				$('#notice_calendar').fullCalendar({
					header: {
						left: 'title',
						right: 'today prev,next'
					},

					//defaultView: 'basicWeek',

					editable: false,
					firstDay: 1,
					height: 530,
					droppable: false,

					events: [
						<?php
						$notices	=	$this->db->get('noticeboard')->result_array();
						foreach($notices as $row):
						?>
						{
							title: "<?php echo $row['notice_title'];?>",
							start: new Date(<?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?>),
							end:	new Date(<?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?>)
						},
						<?php
						endforeach
						?>

					]
				});
	});
  </script>
