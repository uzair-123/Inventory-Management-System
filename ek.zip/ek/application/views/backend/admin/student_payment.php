<hr />
<div class="row">
	<div class="col-md-12">
			
			<ul class="nav nav-tabs bordered">
				<li class="active">
					<a href="#unpaid" data-toggle="tab">
						<span class="hidden-xs"><?php echo get_phrase('create_single_invoice');?></span>
					</a>
				</li>
				<li>
					<a href="#paid" data-toggle="tab">
						<span class="hidden-xs"><?php echo get_phrase('create_mass_invoice');?></span>
					</a>
				</li>
			</ul>
			
			<div class="tab-content">
            <br>
				<div class="tab-pane active" id="unpaid">

				<!-- creation of single invoice -->
				<?php echo form_open(base_url() . 'index.php?admin/invoice/create' , array('class' => 'form-horizontal form-groups-bordered validate','target'=>'_top'));?>
				<div class="row">
					<div class="col-md-6">
	                        <div class="panel panel-default panel-shadow" data-collapsed="0">
	                            <div class="panel-heading">
	                                <div class="panel-title"><?php echo get_phrase('invoice_informations');?></div>
	                            </div>
	                            <div class="panel-body">
	                                
	                                <div class="form-group">
	                                    <label class="col-sm-3 control-label"><?php echo get_phrase('class');?></label>
	                                    <div class="col-sm-9">
	                                        <select name="class_id" class="form-control selectboxit class_id"
	                                        	onchange="return get_class_students(this.value)">
	                                        	<option value=""><?php echo get_phrase('select_class');?></option>
	                                        	<?php 
	                                        		$classes = $this->db->get('class')->result_array();
	                                        		foreach ($classes as $row):
	                                        	?>
	                                        	<option value="<?php echo $row['class_id'];?>"><?php echo $row['name'];?></option>
	                                        	<?php endforeach;?>
	                                            
	                                        </select>
	                                    </div>
	                                </div>

	                                <div class="form-group">
		                                <label class="col-sm-3 control-label"><?php echo get_phrase('student');?></label>
		                                <div class="col-sm-9">
		                                    <select name="student_id" class="form-control" style="width:100%;" id="student_selection_holder" required


                                            onchange="return get_stu_feees(this.value)">
		                                        <option value=""><?php echo get_phrase('select_class_first');?></option>
		                                    </select>
		                                </div>
		                            </div>

                                      <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('Fees');?></label>
                                    <div class="col-sm-9" id="feees">
                                                                              
                                    </div>
                                </div>

	                         
                           
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('title');?></label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="title"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('description');?></label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="description"/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('date');?></label>
                                    <div class="col-sm-9">
                                        <input type="text" class="datepicker form-control" name="date"/>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-default panel-shadow" data-collapsed="0">
                            <div class="panel-heading">
                                <div class="panel-title"><?php echo get_phrase('payment_informations');?></div>
                            </div>
                            <div class="panel-body">
                                
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('total');?></label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" name="amount" id="amount" value=""
                                            placeholder="<?php echo get_phrase('enter_total_amount');?>"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('transport (optional)');?></label>
                                    <div class="col-sm-9">
                                        <input onkeyup="calculate_balance()" type="text" class="form-control" name="optional[]" id="transport" value=0
                                            placeholder="<?php echo get_phrase('transport fees');?>"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('books (optional)');?></label>
                                    <div class="col-sm-9">
                                        <input onkeyup="calculate_balance()" type="text" class="form-control" name="optional[]" id="books" value=0
                                            placeholder="<?php echo get_phrase('books fees');?>"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('cloths (optional)');?></label>
                                    <div class="col-sm-9">
                                        <input onkeyup="calculate_balance()" type="text" class="form-control" name="optional[]" id="clothes" value=0
                                            placeholder="<?php echo get_phrase('cloths fees');?>"/>
                                    </div>
                                </div>

    
    

                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('payment');?></label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="amount_paid" name="amount_paid" value=""
                                            placeholder="<?php echo get_phrase('enter_payment_amount');?>"/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('status');?></label>
                                    <div class="col-sm-9">
                                        <select name="status" class="form-control">
                                            <option value="paid"><?php echo get_phrase('paid');?></option>
                                            <option value="unpaid"><?php echo get_phrase('unpaid');?></option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label"><?php echo get_phrase('method');?></label>
                                    <div class="col-sm-9">
                                        <select name="method" class="form-control">
                                            <option value="1"><?php echo get_phrase('cash');?></option>
                                            <option value="2"><?php echo get_phrase('check');?></option>
                                            <option value="3"><?php echo get_phrase('card');?></option>
                                        </select>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-5">
                                <button type="submit" class="btn btn-info"><?php echo get_phrase('add_invoice');?></button>
                            </div>
                        </div>
                    </div>


	                </div>
	              	<?php echo form_close();?>

				<!-- creation of single invoice -->
					
				</div>
				<div class="tab-pane" id="paid">

				<!-- creation of mass invoice -->
				<?php echo form_open(base_url() . 'index.php?admin/invoice/create_mass_invoice' , array('class' => 'form-horizontal form-groups-bordered validate', 'id'=> 'mass' ,'target'=>'_top'));?>
				<br>
				<div class="row">
				<div class="col-md-1"></div>
				<div class="col-md-5">

					<div class="form-group">
                        <label class="col-sm-3 control-label"><?php echo get_phrase('class');?></label>
                        <div class="col-sm-9">
                            <select name="class_id" class="form-control class_id2"
                            	onchange="return get_class_students_mass(this.value)" required="">
                            	<option value=""><?php echo get_phrase('select_class');?></option>
                            	<?php 
                            		$classes = $this->db->get('class')->result_array();
                            		foreach ($classes as $row):
                            	?>
                            	<option value="<?php echo $row['class_id'];?>"><?php echo $row['name'];?></option>
                            	<?php endforeach;?>
                                
                            </select>
                        </div>
                    </div>

                    

                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?php echo get_phrase('title');?></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="title"
                                data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?php echo get_phrase('description');?></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="description"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?php echo get_phrase('total');?></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="amount"
                                placeholder="<?php echo get_phrase('enter_total_amount');?>"
                                    data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?php echo get_phrase('payment');?></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="amount_paid"
                                placeholder="<?php echo get_phrase('enter_payment_amount');?>"
                                    data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?php echo get_phrase('status');?></label>
                        <div class="col-sm-9">
                            <select name="status" class="form-control selectboxit">
                                <option value="paid"><?php echo get_phrase('paid');?></option>
                                <option value="unpaid"><?php echo get_phrase('unpaid');?></option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?php echo get_phrase('method');?></label>
                        <div class="col-sm-9">
                            <select name="method" class="form-control selectboxit">
                                <option value="1"><?php echo get_phrase('cash');?></option>
                                <option value="2"><?php echo get_phrase('check');?></option>
                                <option value="3"><?php echo get_phrase('card');?></option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?php echo get_phrase('date');?></label>
                        <div class="col-sm-9">
                            <input type="text" class="datepicker form-control" name="date"
                                data-validate="required" data-message-required="<?php echo get_phrase('value_required');?>"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-5 col-sm-offset-3">
                            <button type="submit" class="btn btn-info submit2"><?php echo get_phrase('add_invoice');?></button>
                        </div>
                    </div>
                    


				</div>
				<div class="col-md-6">
					<div id="student_selection_holder_mass"></div>
				</div>
				</div>
				<?php echo form_close();?>

				<!-- creation of mass invoice -->

				</div>
				
			</div>
			
			
	</div>
</div>

<script type="text/javascript">

	function select() {
		var chk = $('.check');
			for (i = 0; i < chk.length; i++) {
				chk[i].checked = true ;
			}

		//alert('asasas');
	}
	function unselect() {
		var chk = $('.check');
			for (i = 0; i < chk.length; i++) {
				chk[i].checked = false ;
			}
	}
</script>

<script type="text/javascript">
    function get_class_students(class_id) {
        if (class_id !== '') {
        $.ajax({
            url: '<?php echo base_url();?>index.php?admin/get_class_students/' + class_id ,
            success: function(response)
            {
                jQuery('#student_selection_holder').html(response);
            }
        });
    }
}





    function get_stu_feees(student_id) {
        if (student_id !== '') {
        $.ajax({
            url: '<?php echo base_url();?>index.php?admin/get_stu_feees/' + student_id ,
            success: function(response)
            {
                jQuery('#feees').html(response);
            }
        });
    }
}










</script>

<script type="text/javascript">
var class_id = '';
jQuery(document).ready(function($) {
    $('.submit').attr('disabled', 'disabled');
});
    function get_class_students_mass(class_id) {
    	if (class_id !== '') {
        $.ajax({
            url: '<?php echo base_url();?>index.php?admin/get_class_students_mass/' + class_id ,
            success: function(response)
            {
                jQuery('#student_selection_holder_mass').html(response);
            }
        });
      }
    }
    function check_validation(){
        if (class_id !== '') {
            $('.submit').removeAttr('disabled');
        }
        else{
            $('.submit').attr('disabled', 'disabled');
        }
    }
    $('.class_id').change(function(){
        class_id = $('.class_id').val();
        check_validation();
    });
</script>


<script>



reparr=new Array();

function loadPaidReport(){

inn=new Array();
sum=0;
var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
inn=reparr;
$('#reporttable > tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              
             if(inn[x].status=="paid"){
              
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              sum+=parseInt(inn[x].amount);
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-secondary">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              }
            
                $('#reporttable > tbody').html(bdy);
                $('#total_amount_span').text('Total Paid:'+sum);
                
    
}

function loadUnPaidReport(){

inn=new Array();
sum=0;
var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
inn=reparr;
$('#reporttable > tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              
             if(inn[x].status=="unpaid"){
              
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              sum+=parseInt(inn[x].amount);
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-secondary">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              }
            
                $('#reporttable > tbody').html(bdy);
                $('#total_amount_span').text('Total Due Payment:'+sum);
    
}

function loadClassreport(){
    
    $('#total_amount_span').text('');
    sum=0;
    
    class_id = $("#class_report option:selected").val();
    start_date = $('#start_date').val();
    end_date = $('#end_date').val();
    
    if(class_id==""){
        alert("Enter Class");
    }
    else if(start_date==""){
        alert("Enter Start Date");
    }
    else if(end_date==""){
        alert("Enter End Date");
    }
    else{
    start_date=new Date(start_date).getTime() / 1000;
    end_date=new Date(end_date).getTime() / 1000;
    
    inn=new Array();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        $.ajax({

            url: '<?php echo base_url();?>index.php?admin/get_inovice_report/' + class_id+'/'+start_date+'/'+end_date ,
            dataType:"json",
            success: function(response)

            {
                
                inn = response;
                reparr = response;
               $('#reporttable > tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              
             if(inn[x].status=="paid"){
                 sum+=parseInt(inn[x].amount);
             }
              
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-secondary">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              
            
                $('#reporttable > tbody').html(bdy);
                $('#total_amount_span').text('Total Paid:'+sum);
               
               
               

            }
            
        });
    
    
    }
    
    
}
function loadInvoice(param){
    
    
    inn=new Array();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        $.ajax({

            url: '<?php echo base_url();?>index.php?admin/get_inovice_by_status/' + param ,
            dataType:"json",
            success: function(response)

            {
                
                inn = response;
               $('tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              
            
              
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
            //  bdy+='<td>'+json_encode( unserialize(inn[x].optional));+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-secondary">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              
              
                $('tbody').html(bdy);
                
               
               
               

            }
            
        });
}



    function handler(e){

  date=e.target.value;
  date=new Date(date).getTime() / 1000;
  

  
  inn=new Array();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        $.ajax({

            url: '<?php echo base_url();?>index.php?admin/get_inovice_by_date/' + date ,
            dataType:"json",
            success: function(response)

            {
                
                inn = response;
               $('tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-secondary">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              
              
                $('tbody').html(bdy);
               
               
               

            }
            
        });
}


    $(document).ready(function(){
        var globalClassId;
          $('select#class_list').on('change', function() {
            globalClassId = $(this).val();
             $.ajax({
                url: '<?php echo base_url();?>index.php?admin/get_class_section_for_invoice/'+globalClassId,
                method: 'post',
                beforeSend: function() {
                    $('select#section_list').css('cursor','wait');
                },
                complete: function(){
                    $('select#section_list').css('cursor','pointer');
                },        
                success: function(response) {
                    
                    
                    if (response=='')
                    {
                        response ="<option>section</option><option>Only one section</option>"
                    }
                    $('select#section_list').html(response);
                    //$('select#student_list').html("<option></option>");
                    
                }
             });
         });
         
         
         $('select#section_list').on('change', function() {
            
            var sectionId = $(this).val();
             $.ajax({
                url: '<?php echo base_url();?>index.php?admin/get_studentList_for_invoice',
                method: 'post',
                data:{classId:globalClassId,section_id:sectionId},
                beforeSend: function() {
                    $('select#student_list').css('cursor','wait');
                },
                complete: function(){
                    $('select#student_list').css('cursor','pointer');
                },        
                success: function(response) {
                    //alert(response);
                    //$('select#student_list').html(response);
                    
                }
             });
         });
         
    
         
 }); 

 
 function calculate_balance(){
     
      document.getElementById("amount").value = parseInt($('#fee').val()) + parseInt($('#transport').val()) + parseInt($('#books').val())+ parseInt($('#clothes').val());   
 }
 



 
 function getval(sel){      

 
 $.ajax({      
 url: '<?php echo base_url();?>index.php?admin/get_fees/' + sel.value ,   
 success: function(response)   
 {                      
 document.getElementById("fees").value = response;   
 document.getElementById("amount_paid").value = response;   
 calculate_balance();
 }        });   
 std=new Array();
 
            $.ajax({      
                url: '<?php echo base_url();?>index.php?admin/get_students/' + sel.value ,   
                dataType:"json",
                    success: function(response)   
                        {                       
                            std = response;
                            
                            res="";
                            for(x=0;x<std.length;x++){
                                
                                res+="<option value="+std[x].student_id+">"+std[x].name+"</option>";
                            }
                            
                            $('select#student_list').html(res);
                            
                            }           
                            });   
 }
 
 
</script>