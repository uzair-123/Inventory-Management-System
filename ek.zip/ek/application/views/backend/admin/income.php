<style>
#loader{ cursor: wait;
    
    opacity: 0.75;
    position: absolute;
    z-index: 10000;
   }
   .new_button{
	   
	   background: #00a651;
    color: white;
    margin: 10px;
    padding: 10px;
    border: none;
    width: 90px;
   }
   
   
</style>

<script>
paidsum=0;

function sum(sum){
	paidsum=sum;
$('#total_amount_span1').text('Total Paid:'+sum);

}
function unpaidsum(sum){
	$('#total_amount_span1').text('Total Due Payment:'+sum);
}


</script>

<?php  $sum=0;
		$unpaidsum=0;
		foreach($invoices as $row):
		
							if($row['status']=='paid')
							$sum+=$row['amount'];
						else
							$unpaidsum+=$row['amount'];
		endforeach;
 ?>











<hr />
<div class="row">
	<div class="col-md-12">

			<ul class="nav nav-tabs bordered">
				<li class="<?php if($active_tab == 'invoices') echo 'active'; ?>">
					<a href="#unpaid" data-toggle="tab">
						<span class="hidden-xs"><?php echo get_phrase('invoices');?></span>
					</a>
				</li>
				<li>
					<a href="#paid" data-toggle="tab">
						<span class="hidden-xs"><?php echo get_phrase('payment_history');?></span>
					</a>
				</li>
				<li class="<?php if($active_tab == 'student_specific_payment_history') echo 'active'; ?>">
					<a href="#paid_student_specific" data-toggle="tab">
						<span class="hidden-xs"><?php echo get_phrase('student_specific_payment_history');?></span>
					</a>
				</li>


<li>
					<a href="#report" data-toggle="tab">
						<span class="hidden-xs"><?php echo get_phrase('class report');?></span>
					</a>
				</li>



			</ul>

			<div class="tab-content">
			<br>
				   <div class="tab-pane box active" id="unpaid">
				<div>
	 
        <form action="" method="post" style="display: inline;">


        
		<label> &nbsp &nbsp &nbsp &nbsp Start Date &nbsp &nbsp<input name="frm" type="date"  /></label>
			<label> &nbsp &nbsp &nbsp &nbspEnd Date &nbsp &nbsp<input type="date" name="to" /></label>



  	<select name="status" style="margin-left: 25px; margin-right: 25px" onchange="this.form.submit()">

  		<option>Select Payment Status</option>
		<option value="paid" ><button >
		Paid
		</button></option>


	<option  value="unpaid" ><button>
		Unpaid
		</button></option>

		</select>
      




	</form>







		<span>

      <?php 

     if(isset($_POST['status']))
     {
    
      $status = $_POST['status'] ;
       $frm = $_POST['frm'] ;

       
$time  = strtotime($frm);
$day   = date('d',$time);
$month = date('m',$time);
$year  = date('Y',$time);

$frm = $year . "/" . $month . "/" . $day; 

      

      



    
       $to = $_POST['to'] ;
$time  = strtotime($to);
$day   = date('d',$time);
$month = date('m',$time);
$year  = date('Y',$time);

$to = $year . "/" . $month . "/" . $day; 



     

       	
	

     $servername = "localhost";
			$username = "root" ;
			$password = "123456";
			$dbname = "ekattor";
			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);  
 
   if($status == "paid")
   {



   $sql = "select * from invoice" ;

   $result = $conn->query($sql) ;

   $sum = 0 ; 

   while($row = $result->fetch_assoc()) {

   	$daty = date('Y/m/d', $row['creation_timestamp']) ;

   	$orderdate = explode('/', $daty);
$month = $orderdate[1];
$day   = $orderdate[2];
$year  = $orderdate[0];



if($daty >= $frm && $daty <= $to)
{

$sum += $row['amount_paid'] ;
}




   }

   
   // echo 'TOTAL PAID AMOUNT:'. $row['sumy_paid']. ' ' ;

   
   echo 'TOTAL PAID AMOUNT:&nbsp'. $sum . '' ;

}

else
{

	
   $sql = "select * from invoice" ;

   $result = $conn->query($sql) ;

   $sum = 0 ; 

   while($row = $result->fetch_assoc()) {

   	$daty = date('Y/m/d', $row['creation_timestamp']) ;

   	$orderdate = explode('/', $daty);
$month = $orderdate[1];
$day   = $orderdate[2];
$year  = $orderdate[0];



if($daty >= $frm && $daty <= $to)
{

$sum += $row['due'] ;
}




   }

   
   // echo 'TOTAL PAID AMOUNT:'. $row['sumy_paid']. ' ' ;

   
   echo 'TOTAL DUE AMOUNT: &nbsp  '. $sum . '' ;
}


   

     }

     else
     {
     	echo "not";
     }

      ?>
		</span>
		
		</div>
                <table  class="table table-bordered datatable" id="table_export">
                	<thead>
                		<tr>
                    		<th><div><?php echo get_phrase('student');?></div></th>
                    		<th><div><?php echo get_phrase('title');?></div></th>
                    		<th><div><?php echo get_phrase('transport');?></div></th>
                    		<th><div><?php echo get_phrase('books');?></div></th>
                    		<th><div><?php echo get_phrase('clothes');?></div></th>
                            <th><div><?php echo get_phrase('total');?></div></th>
                            <th><div><?php echo get_phrase('paid');?></div></th>
                    		<th><div><?php echo get_phrase('status');?></div></th>
                    		<th><div><?php echo get_phrase('date');?></div></th>
                    		<th><div><?php echo get_phrase('options');?></div></th>
						</tr>
					</thead>
                    <tbody>
                    	<?php foreach($invoices as $row):?>
                        <tr>
							<td><?php echo $this->crud_model->get_type_name_by_id('student',$row['student_id']);?></td>
							<td><?php echo $row['title'];?></td>
							<td><?php echo unserialize($row['optional'])[0];?></td>
							<td><?php echo unserialize($row['optional'])[1];?></td>
							<td><?php echo unserialize($row['optional'])[2];?></td>
							<td><?php echo $row['amount'];?></td>
							
                            <td><?php echo $row['amount_paid'];?></td>
							<td>
								<span class="label label-<?php if($row['status']=='paid')echo 'success';else echo 'danger';?>"><?php echo $row['status'];?></span>
							</td>
							<td><?php echo date('d M,Y', $row['creation_timestamp']);?></td>
							<td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                                    Action <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu dropdown-default pull-right" role="menu">

                                    <?php if ($row['due'] != 0):?>

                                    <li>
                                        <a href="#" onclick="showAjaxModal('<?php echo base_url();?>index.php?modal/popup/modal_take_payment/<?php echo $row['invoice_id'];?>');">
                                            <i class="entypo-bookmarks"></i>
                                                <?php echo get_phrase('take_payment');?>
                                        </a>
                                    </li>
                                    <li class="divider"></li>
                                    <?php endif;?>
                                    
                                    <!-- VIEWING LINK -->
                                    <li>
                                        <a href="#" onclick="showAjaxModal('<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/<?php echo $row['invoice_id'];?>');">
                                            <i class="entypo-credit-card"></i>
                                                <?php echo get_phrase('view_invoice');?>
                                            </a>
                                                    </li>
                                    <li class="divider"></li>
                                    
                                    <!-- EDITING LINK -->
                                    <li>
                                        <a href="#" onclick="showAjaxModal('<?php echo base_url();?>index.php?modal/popup/modal_edit_invoice/<?php echo $row['invoice_id'];?>');">
                                            <i class="entypo-pencil"></i>
                                                <?php echo get_phrase('edit');?>
                                        </a>
                                    </li>
                                    <li class="divider"></li>

                                    <!-- DELETION LINK -->
                                    <li>
                                        <a href="#" onclick="confirm_modal('<?php echo base_url();?>index.php?admin/invoice/delete/<?php echo $row['invoice_id'];?>');">
                                            <i class="entypo-trash"></i>
                                                <?php echo get_phrase('delete');?>
                                            </a>
                                                    </li>
                                </ul>
                            </div>
        					</td>
                        </tr>
                        <?php endforeach;?>
						<?php 
						echo "<script> sum(".$sum."); </script>";
	 ?>
                    </tbody>
                </table>
			</div>
				<div class="tab-pane" id="paid">

					<table class="table table-bordered datatable example">
					    <thead>
					        <tr>
					            <th><div>#</div></th>
					            <th><div><?php echo get_phrase('title');?></div></th>
					            <th><div><?php echo get_phrase('description');?></div></th>
					            <th><div><?php echo get_phrase('method');?></div></th>
					            <th><div><?php echo get_phrase('amount');?></div></th>
					            <th><div><?php echo get_phrase('date');?></div></th>
					            <th></th>
					        </tr>
					    </thead>
					    <tbody>
					        <?php
					        	$count = 1;
					        	$this->db->where('payment_type' , 'income');
					        	$this->db->order_by('timestamp' , 'desc');
					        	$payments = $this->db->get('payment')->result_array();
					        	foreach ($payments as $row):
					        ?>
					        <tr>
					            <td><?php echo $count++;?></td>
					            <td><?php echo $row['title'];?></td>
					            <td><?php echo $row['description'];?></td>
					            <td>
					            	<?php
					            		if ($row['method'] == 1)
					            			echo get_phrase('cash');
					            		if ($row['method'] == 2)
					            			echo get_phrase('check');
					            		if ($row['method'] == 3)
					            			echo get_phrase('card');
					                    if ($row['method'] == 'paypal')
					                    	echo 'paypal';
					            	?>
					            </td>
					            <td><?php echo $row['amount'];?></td>
					            <td><?php echo date('d M,Y', $row['timestamp']);?></td>
					            <td align="center">
					            	<a href="#" onclick="showAjaxModal('<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/<?php echo $row['invoice_id'];?>');"
					            		class="btn btn-default">
					            			<?php echo get_phrase('view_invoice');?>
					            	</a>
					            </td>
					        </tr>
					        <?php endforeach;?>
					    </tbody>
					</table>

				</div>

				<div class="tab-pane <?php if($active_tab == 'student_specific_payment_history') echo 'active'; ?>" id="paid_student_specific">

					<br>
					<?php echo form_open(base_url() . 'index.php?admin/income/student_specific_payment_history/filter_history');?>
						<div class="row">

							<div class="col-md-offset-4 col-md-3">
								<div class="form-group">
									<select name="student_id" class="form-control selectboxit">
										<option value="all" <?php if($student_id == 'all') echo 'selected'; ?>>
											<?php echo get_phrase('all_students');?>
										</option>
										<?php
										$enrolls = $this->db->get_where('enroll', array('year' =>  $running_year))->result_array();
										print_r($enrolls);
										foreach($enrolls as $row) {
											$student_info = $this->db->get_where('student', array('student_id' =>  $row['student_id']))->row(); ?>
											<option value="<?php echo $row['student_id']; ?>" <?php if($student_id == $row['student_id']) echo 'selected'; ?>>
												<?php echo $student_info->name; ?>
											</option>
										<?php } ?>
									</select>
								</div>
							</div>

							<div class="col-md-2">
								<button type="submit" class="btn btn-info" style="margin-top: 5px;"><?php echo get_phrase('search');?></button>
							</div>

						</div>
					<?php echo form_close();?>

					<table class="table table-bordered datatable example">
					    <thead>
					        <tr>
					            <th><div>#</div></th>
					            <th><div><?php echo get_phrase('title');?></div></th>
					            <th><div><?php echo get_phrase('description');?></div></th>
					            <th><div><?php echo get_phrase('method');?></div></th>
					            <th><div><?php echo get_phrase('amount');?></div></th>
					            <th><div><?php echo get_phrase('date');?></div></th>
					            <th></th>
					        </tr>
					    </thead>
					    <tbody>
					        <?php
				        	$count = 1;
				        	if($student_id != 'all')
				        		$this->db->where('student_id', $student_id);
				        	$this->db->where('payment_type' , 'income');
				        	$this->db->order_by('timestamp' , 'desc');
				        	$payments = $this->db->get('payment')->result_array();
				        	foreach ($payments as $row): ?>
						        <tr>
						            <td><?php echo $count++;?></td>
						            <td><?php echo $row['title'];?></td>
						            <td><?php echo $row['description'];?></td>
						            <td>
						            	<?php
						            		if ($row['method'] == 1)
						            			echo get_phrase('cash');
						            		if ($row['method'] == 2)
						            			echo get_phrase('check');
						            		if ($row['method'] == 3)
						            			echo get_phrase('card');
						                    if ($row['method'] == 'paypal')
						                    	echo 'paypal';
						            	?>
						            </td>
						            <td><?php echo $row['amount'];?></td>
						            <td><?php echo date('d M,Y', $row['timestamp']);?></td>
						            <td align="center">
						            	<a href="#" onclick="showAjaxModal('<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/<?php echo $row['invoice_id'];?>');"
						            		class="btn btn-default">
						            			<?php echo get_phrase('view_invoice');?>
						            	</a>
						            </td>
						        </tr>
					        <?php endforeach; ?>
					    </tbody>
					</table>

				</div>



       


<!-- CLASS REPORT STARTS --> 




<div class="tab-pane box" id="report">
				<div>
				
	<select style="    display: inline;width: 15%;" name="class_report" id="class_report" class="form-control" style="" >
                                           <option disabled selected value>--select class-- </option>
					
                                            <?php 
                                            $this->db->order_by('class_id','asc');
                                            $class = $this->db->get('class')->result_array();
                                            	foreach($class as $row):
                                            
											?>
                                                <option value="<?php echo $row['class_id'];?>">
                                                
                                                 <?php echo  $row['name']?>
                                                </option>
                                            <?php
                                            endforeach;
                                            ?>
                                        </select>
										<label class=""><?php echo get_phrase('Start Date');?></label>
										<input type="date" id="start_date" />
										<label class=""><?php echo get_phrase('End Date');?></label>
										<input type="date" id="end_date" />
										
										<button style="background:black" class="new_button" onclick="loadClassreport()">
		Search
		</button>
										
		<button class="new_button" onclick="loadPaidReport()">
		Paid
		</button>
		<button style="background:#ffba00" class="new_button" onclick="loadUnPaidReport()">
		Unpaid
		</button>
		<span id="total_amount_span"></span>
		
		</div>
                <table id="reporttable"  class="table table-bordered datatable">
                	<thead>
                		<tr>
                    		<th><div><?php echo get_phrase('student');?></div></th>
                    		<th><div><?php echo get_phrase('title');?></div></th>
                    		<th><div><?php echo get_phrase('transport');?></div></th>
                    		<th><div><?php echo get_phrase('books');?></div></th>
                    		<th><div><?php echo get_phrase('clothes');?></div></th>
                            <th><div><?php echo get_phrase('total');?></div></th>
                            <th><div><?php echo get_phrase('paid');?></div></th>
                    		<th><div><?php echo get_phrase('status');?></div></th>
                    		<th><div><?php echo get_phrase('date');?></div></th>
                    		<th><div><?php echo get_phrase('options');?></div></th>
						</tr>
					</thead>
                    <tbody>


                  
                    </tbody>
                </table>
			</div>












<!-- CLASS REPORT ENDS -->
































			</div>


	</div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function($)
	{


		var datatable = $(".example").dataTable({
			"sPaginationType": "bootstrap",

		});

		$(".dataTables_wrapper select").select2({
			minimumResultsForSearch: -1
		});
	});
</script>




<script type="text/javascript">
    function get_class_students(class_id) {
        if (class_id !== '') {
        $.ajax({
            url: '<?php echo base_url();?>index.php?admin/get_class_students/' + class_id ,
            success: function(response)
            {
                jQuery('#student_selection_holder').html(response);
            }
        });
    }
}
</script>

<script type="text/javascript">
var class_id = '';
jQuery(document).ready(function($) {
    $('.submit').attr('disabled', 'disabled');
});
    function get_class_students_mass(class_id) {
    	if (class_id !== '') {
        $.ajax({
            url: '<?php echo base_url();?>index.php?admin/get_class_students_mass/' + class_id ,
            success: function(response)
            {
                jQuery('#student_selection_holder_mass').html(response);
            }
        });
      }
    }
    function check_validation(){
        if (class_id !== '') {
            $('.submit').removeAttr('disabled');
        }
        else{
            $('.submit').attr('disabled', 'disabled');
        }
    }
    $('.class_id').change(function(){
        class_id = $('.class_id').val();
        check_validation();
    });
</script>


<script>



reparr=new Array();

function loadPaidReport(){

inn=new Array();
sum=0;
var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
inn=reparr;
$('#reporttable > tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              
             if(inn[x].status=="paid"){
              
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              sum+=parseInt(inn[x].amount);
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-danger">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              }
            
                $('#reporttable > tbody').html(bdy);
                $('#total_amount_span').text('Total Paid:'+sum);
                
    
}

function loadUnPaidReport(){

inn=new Array();
sum=0;
var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
inn=reparr;
$('#reporttable > tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              
             if(inn[x].status=="unpaid"){
              
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              sum+=parseInt(inn[x].amount);
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-danger">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              }
            
                $('#reporttable > tbody').html(bdy);
                $('#total_amount_span').text('Total Due Payment:'+sum);
    
}

function loadClassreport(){
    
    $('#total_amount_span').text('');
    sum=0;
    
    class_id = $("#class_report option:selected").val();
    start_date = $('#start_date').val();
    end_date = $('#end_date').val();


    
    if(class_id==""){
        alert("Enter Class");
    }
    else if(start_date==""){
        alert("Enter Start Date");
    }
    else if(end_date==""){
        alert("Enter End Date");
    }
    else{
    start_date=new Date(start_date).getTime() / 1000;
    end_date=new Date(end_date).getTime() / 1000;
    
    inn=new Array();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        $.ajax({

            url: '<?php echo base_url();?>index.php?admin/get_inovice_report/' + class_id+'/'+start_date+'/'+end_date ,
            dataType:"json",
            success: function(response)

            {
                
                inn = response;
                reparr = response;
               $('#reporttable > tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              
             if(inn[x].status=="paid"){
                 sum+=parseInt(inn[x].amount);
             }
              
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-danger">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              
            
                $('#reporttable > tbody').html(bdy);
                $('#total_amount_span').text('Total Paid:'+sum);
               
               
               

            }
            
        });
    
    
    }
    
    
}
function loadInvoice(param){
    
    
    inn=new Array();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        $.ajax({

            url: '<?php echo base_url();?>index.php?admin/get_inovice_by_status/' + param ,
            dataType:"json",
            success: function(response)

            {
                
                inn = response;
               $('tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              
            
              
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
            //  bdy+='<td>'+json_encode( unserialize(inn[x].optional));+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-danger>'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              
              
                $('tbody').html(bdy);
                
               
               
               

            }
            
        });
}



    function handler(e){

  date=e.target.value;
  date=new Date(date).getTime() / 1000;
  

  
  inn=new Array();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    
        $.ajax({

            url: '<?php echo base_url();?>index.php?admin/get_inovice_by_date/' + date ,
            dataType:"json",
            success: function(response)

            {
                
                inn = response;
               $('tbody').html('');

                bdy="";
                
        
              
              for(x=0;x<inn.length;x++){ 
              bdy+='<tr><td>'+inn[x].name+'</td>';
              bdy+='<td>'+inn[x].title+''+'</td>';
              bdy+='<td>'+inn[x].transport+''+'</td>';
              bdy+='<td>'+inn[x].books+''+'</td>';
              bdy+='<td>'+inn[x].clothes+''+'</td>';
              bdy+='<td>'+inn[x].amount+'</td> <td>'+inn[x].amount_paid+'</td>';
              if(inn[x].status=="paid"){
                   bdy+='<td><span class="label label-success">'+inn[x].status+'</span></td>'
              }
              else{
                  
                  bdy+='<td><span class="label label-danger">'+inn[x].status+'</span></td>'
                   
              }
              date=new Date(inn[x].creation_timestamp*1000);
              
              
              bdy+='<td>'+date.getDate() + ' ' + months[date.getMonth()] +','+date.getFullYear() +'</td>';
              
              bdy+='<td><div class="btn-group"><button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown"> Action <span class="caret"></span></button><ul class="dropdown-menu dropdown-default pull-right" role="menu">';
              if(inn[0].due!=0){
                  
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_take_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-bookmarks"></i><?php echo get_phrase('take_payment');?></a></li> <li class="divider"></li>';
                
              }
              
              bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-credit-card"></i><?php echo get_phrase('view_payment');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="showAjaxModal(\'<?php echo base_url();?>index.php?modal/popup/modal_edit_payment/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-pencil""></i><?php echo get_phrase('edit');?></a></li> <li class="divider"></li>';
                
                bdy+='  <li><a href="#" onclick="confirm_modal(\'<?php echo base_url();?>index.php?admin/invoice/delete/'+inn[x].invoice_id+'\');">';
                bdy+='<i class="entypo-trash"></i><?php echo get_phrase('delete');?></a></li> <li class="divider"></li>';
                bdy+='</ul> </div></td> </tr>';
                }
              
              
                $('tbody').html(bdy);
               
               
               

            }
            
        });
}


    $(document).ready(function(){
        var globalClassId;
          $('select#class_list').on('change', function() {
            globalClassId = $(this).val();
             $.ajax({
                url: '<?php echo base_url();?>index.php?admin/get_class_section_for_invoice/'+globalClassId,
                method: 'post',
                beforeSend: function() {
                    $('select#section_list').css('cursor','wait');
                },
                complete: function(){
                    $('select#section_list').css('cursor','pointer');
                },        
                success: function(response) {
                    
                    
                    if (response=='')
                    {
                        response ="<option>section</option><option>Only one section</option>"
                    }
                    $('select#section_list').html(response);
                    //$('select#student_list').html("<option></option>");
                    
                }
             });
         });
         
         
         $('select#section_list').on('change', function() {
            
            var sectionId = $(this).val();
             $.ajax({
                url: '<?php echo base_url();?>index.php?admin/get_studentList_for_invoice',
                method: 'post',
                data:{classId:globalClassId,section_id:sectionId},
                beforeSend: function() {
                    $('select#student_list').css('cursor','wait');
                },
                complete: function(){
                    $('select#student_list').css('cursor','pointer');
                },        
                success: function(response) {
                    //alert(response);
                    //$('select#student_list').html(response);
                    
                }
             });
         });
         
    
         
 }); 

 
 function calculate_balance(){
     
      document.getElementById("amount").value = parseInt($('#fees').val()) + parseInt($('#transport').val()) + parseInt($('#books').val())+ parseInt($('#clothes').val());   
 }
 
 
 function getval(sel){      

 
 $.ajax({      
 url: '<?php echo base_url();?>index.php?admin/get_fees/' + sel.value ,   
 success: function(response)   
 {                      
 document.getElementById("fees").value = response;   
 document.getElementById("amount_paid").value = response;   
 calculate_balance();
 }        });   
 std=new Array();
 
            $.ajax({      
                url: '<?php echo base_url();?>index.php?admin/get_students/' + sel.value ,   
                dataType:"json",
                    success: function(response)   
                        {                       
                            std = response;
                            
                            res="";
                            for(x=0;x<std.length;x++){
                                
                                res+="<option value="+std[x].student_id+">"+std[x].name+"</option>";
                            }
                            
                            $('select#student_list').html(res);
                            
                            }           
                            });   
 }
 
 
</script>