<!DOCTYPE html>
<html lang="en">
<head>
<style>

.glyphicon-lock{
  padding: 15px 0px; 
  font-size:82px;
  color:#fff;
}
.login-text{
  color:#fff;
  font-size:32px !important; 
  font-weight:700;
  padding-bottom:0px;
}

input[placeholder], [placeholder], *[placeholder] {
    font-size:22px;
  color:#666362;
}

.form-control{
  width:60%;
  height:48px !important;
}
.light-black{
  background-color:#666362;
  padding:45px 0px 65px 0px;
}
.red{
  background-color:#F75D59;
}
.yellow{
  background-color:#FDD017;
  padding:75px 30px;
}
.green{
  background-color:#6CC417;
  padding:75px 30px;
}
.skyblue{
  background-color:#48CCCD !important;
}
.login_heading_text{
  font-size:85px;
  padding:25px 5px;
  text-align:center;
  font-weight:bolder;
  color:#fff;
}
span{
  font-size:26px;
  color:#fff;
  padding:20px 0px 10px 0px;
}

.link
{
  margin-left:123px;
  font-weight:700;
  font-size:14px;
  color:#fff;
}

</style>


  <?php
  $system_name  = $this->db->get_where('settings' , array('type'=>'system_name'))->row()->description;
  $system_title = $this->db->get_where('settings' , array('type'=>'system_title'))->row()->description;
  ?>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Neon Admin Panel" />
  <meta name="author" content="" />
  
  <title><?php echo get_phrase('login');?> | <?php echo $system_title;?></title>
  

  <link rel="stylesheet" href="assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css">
  <link rel="stylesheet" href="assets/css/font-icons/entypo/css/entypo.css">
  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic">
  <link rel="stylesheet" href="assets/css/bootstrap.css">
  <link rel="stylesheet" href="assets/css/neon-core.css">
  <link rel="stylesheet" href="assets/css/neon-theme.css">
  <link rel="stylesheet" href="assets/css/neon-forms.css">
  <link rel="stylesheet" href="assets/css/custom.css">

  <script src="assets/js/jquery-1.11.0.min.js"></script>

  <!--[if lt IE 9]><script src="assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
  <link rel="shortcut icon" href="assets/images/favicon.png">
  
</head>

<body class="skyblue" data-url="http://neon.dev">


<!-- This is needed when you send requests via Ajax -->
<script type="text/javascript">
var baseurl = '<?php echo base_url();?>';
</script>

<div class="login-container" >

  <h1 class="login_heading_text">سلام هاسټ ښوونځۍ مدریت سافټویر</h1>

      <form method="post" role="form" id="form_login"
            action="<?php echo base_url();?>index.php?login/validate_login">
      
    <div class="col-sm-12 light-black">
      <div class="col-sm-2">
        <div class="red">
          <img src="uploads/logo2.png" height="100%" width="100%" alt="" />
        </div>
      </div>
      
      <div class="col-sm-4">
        <div class="green">
        <input type="text" class="form-control center-block" name="email" id="email" placeholder="Email" autocomplete="off" data-mask="email" />
        </div>
      </div>
      
      <div class="col-sm-4">
        <div class="yellow">
        <input type="password" class="form-control center-block" name="password" id="password" placeholder="Password" autocomplete="off" />
        </div>
      </div>
      
      <div class="col-sm-2">
        <div class="skyblue">
          <div class="form-group">
          <i class="glyphicon glyphicon-lock center-block"></i>
          </div>
          <button type="submit" value="Login" class="btn btn-primary btn-block btn-login login-text text-center">
            <h3 class="login-text text-center">Login</h3>
          </button> 
        </div>
      </div>
      
      <div class="clearfix"></div>
      
      <div class="col-sm-3">
        <span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> &nbsp <span>+93 (0) 707 00 9795</span>
      </div>

      <div class="col-sm-3">
        <span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> &nbsp <span>Info@salaamhost.com</span>
      </div>

      <div class="col-sm-3">
      <span class="glyphicon glyphicon-globe" aria-hidden="true"></span> &nbsp  <span>www.salaamhost.com</span>
      </div>  
      
      
      <div class="col-sm-3" style="padding-top:22px;">
        <div class="login-bottom-links text-center">
        <a href="<?php echo base_url();?>index.php?login/forgot_password" class="link">
          <?php echo get_phrase('forgot_your_password');?> ?
        </a>
        </div>
      </div>      
      
      
    </div>
      
  </form>
  

  <!--<div class="login-progressbar">
    <div></div>
  </div>-->
<!--  
  <div class="login-form1">
    
    <div class="login-content">
      
      <form method="post" role="form" id="" action="">
        
        <div class="form-group">
          
          <div class="input-group">
            <div class="input-group-addon">
              <i class="entypo-user"></i>
            </div>
            
            <input type="text" class="form-control" name="email" id="email" placeholder="Email" autocomplete="off" data-mask="email" />
          </div>
          
        </div>
        
        <div class="form-group">
          
          <div class="input-group">
            <div class="input-group-addon">
              <i class="entypo-key"></i>
            </div>
            
            <input type="password" class="form-control" name="password" id="password" placeholder="Password" autocomplete="off" />
          </div>
        
        </div>
        
        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-block btn-login">
            <i class="entypo-login"></i>
            Login
          </button>
        </div>
        
            
      </form>
      
      
      <div class="login-bottom-links">
        <a href="<?php //echo base_url();?>index.php?login/forgot_password" class="link">
          <?php //echo get_phrase('forgot_your_password');?> ?
        </a>
      </div>
      
    </div>
    
  </div>
  -->
  
  
</div>


  <!-- Bottom Scripts -->
  <script src="assets/js/gsap/main-gsap.js"></script>
  <script src="assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
  <script src="assets/js/bootstrap.js"></script>
  <script src="assets/js/joinable.js"></script>
  <script src="assets/js/resizeable.js"></script>
  <script src="assets/js/neon-api.js"></script>
  <script src="assets/js/jquery.validate.min.js"></script>
  <!--<script src="assets/js/neon-login.js"></script>-->
  <script src="assets/js/neon-custom.js"></script>
  <script src="assets/js/neon-demo.js"></script>

</body>
</html>